from django.apps import AppConfig


class SufeikejiConfig(AppConfig):
    name = 'sufeikeji'
