from django.shortcuts import render
from sufeikeji.models.sourcemodel import Source_Info,Source

def SourceMethord(request):

    source = Source.objects.all()

    #return HttpResponse("Hello world")
    return render(request, 'source.html', {'source':source})