from django.db import models

class Source(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.TextField()

class Source_Info(models.Model):

    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=45)
    detail = models.CharField(max_length=45)
    source = models.ForeignKey('Source',on_delete=models.DO_NOTHING)

