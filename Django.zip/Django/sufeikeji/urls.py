
from django.urls import path
from sufeikeji.source import source
from sufeikeji.test import test
from sufeikeji.login import login

urlpatterns = [
    path("source/", source.SourceMethord),
    path("test/", test.TestMethord),
    path('login/', login.LoginMethord),
]


