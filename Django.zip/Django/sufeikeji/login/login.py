from django.shortcuts import render
from sufeikeji.models.sourcemodel import Source_Info,Source

def LoginMethord(request):

    source = Source.objects.all()
    return render(request, 'login.html', {'source': source})