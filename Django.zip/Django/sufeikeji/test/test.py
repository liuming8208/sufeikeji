from django.shortcuts import render
from sufeikeji.models.sourcemodel import Source_Info

def TestMethord(request):

    #source = Source.objects.values('name')
    #source = Source.objects.values_list('name')
    #source = Source.objects.count()
    #source = Source.objects.filter(name='测试1')
    #source = Source.objects.filter(id__gt=1)
    #source = Source.objects.filter(id__lt=3)
    #source = Source.objects.filter(id__in=[1,3])
    #source = Source.objects.filter(id__range=[1,2])
    #source = Source.objects.filter(name__contains='2')

    #source = Source.objects.filter(id__range=[1, 2]).order_by('id')
    #source = Source.objects.filter(id__range=[1, 4]).order_by('-id')

    #source = Source.objects.filter(id__range=[1, 4]).values('name').annotate(Count('name'))

    #source = Source_Info.objects.all()
    #source = Source_Info.objects.filter(source__name__contains='2')

    source = Source_Info.objects.all()

    return  render(request,'test.html',{'source':source})
